# Neloy Enterprise website: notes for a new chat

Owner: Neloy, Netrakona, Bangladesh. Phone / WhatsApp: 01722884496.
Business: custom aluminium, glass, mirror and melamine-board products for homes, shops and offices.
Site: one file, `index.html` (about 2.8 MB, photos are embedded). Hosted on Vercel from GitHub.

## How to work with me (the owner)
- First tell me in plain, simple English what you understood. Wait for my OK before big changes.
- One task per message. Do not change other pages unless I say so.
- Test desktop and phone widths. No sideways scrolling.
- Never invent prices, years of experience or claims. Show "Price not configured" when a price is missing.
- Keep replies short. Give me the updated file only when it is tested.

## Pages (views) in index.html
Home, Shop, Projects, About, Blog, Contact, and these configurators:
- `configure` : glass and aluminium (windows, doors, partitions, fixed glass), 2D + 3D
- `shelfconfig` : shelf / cabinet builder (columns, compartments, doors, drawers, back), drag and drop
- `tablecfg` : study table with hutch
- `wscfg` : wall shelf unit (two cube units with floating shelves)
- `sccfg` : shop counter (red board base + glass and aluminium display case). Needs the same click-and-drag editor as the shelf builder (not done yet)
- `ceiling` : PVC ceiling estimator (room size, materials, prices)

## Shared look and behaviour
- Colours: dark green #2C4A38, sage #7E8C82, cream backgrounds. Font: Hanken Grotesk (Bengali: Noto Sans Bengali).
- Every configurator uses the same layout: steps on the left, price bar with "Order now" and "WhatsApp" at the bottom of the left panel, 3D preview and tools on the right. On phones the preview comes first and the price bar is fixed at the bottom.
- Units: inch, suta (1 inch = 8 suta), millimetre.
- 3D view: simple boxes, drag left/right to rotate 360 degrees, doors and drawers open with the Open button.
- Price, 3D model and cutting list must come from the same parts list.

## Pricing rules
- Board price: 1 board = BDT 1,700; fitting = BDT 1,000 per board. Board size 4 x 8 ft = 32 sq ft. Boards needed = parts area / 32, rounded up. No manual board-count box for customers.
- Glass and aluminium configurator: the price formula stays hidden from customers (Details shows only product, size, glass, colour and total).
- Glass rates known: Clear 5 mm = 115 per sq ft, Blue Mercury 5.5 mm = 180 per sq ft. Clear 3.5 mm and Colour 5 mm: not set yet.
- Aluminium profile: placeholder 180 per ft. Door hardware, drawer, sliding track, labour and other: not set yet.
- Pricing settings are shared by all configurators.

## Shop
- Categories (same as home): Glass & Aluminium, Showcases & Furniture, Home Decor. Buttons show product counts.
- "All" shows grouped sections. Search and sort show one flat list.
- Cards: photo, category label, name, short description, price, "Customise" (opens configurator) and "Order" (WhatsApp with product name).
- Hero search box on the home page opens a configurator or the Shop. Keep it working.

## Known to-do
1. Split the site into index.html, style.css, main.js, products.js and an images folder.
2. Shop counter: click-and-drag editing like the shelf builder; click a compartment to choose open / door / glass door / drawer.
3. Real prices for every product and a real mirror photo.
4. Quote basket (one WhatsApp message with several products) and a share-design link.
5. Project photos, "How to measure" page, payment and delivery notes.
6. Tighter spacing and better phone layout on the home page.

## Do not
- Do not copy third-party template code or text.
- Do not add the Wall Decor / Aquarium / Showcase cards back to wrong configurators.
- Do not paste passwords or tokens in chat.
